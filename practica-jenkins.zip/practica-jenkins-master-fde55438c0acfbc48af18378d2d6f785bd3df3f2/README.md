# JENKINS-LAB PRAGMA
Este repositorio contiene todos los recursos tecnológicos que necesitarás para 
el correcto desarrollo de la práctica DevOps asociada al planeta de Jenkins. <br>

A continuación te explicaremos de forma general el repositorio: <br>

<!-- TODO: Complete main README.md -->
